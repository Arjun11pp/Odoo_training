# -*- coding: utf-8 -*-

from odoo import api, fields, models

class ResPartner(models.Model):
    """Inherits from res_partner model"""
    _inherit = "res.partner"

    most_product_sold = fields.Many2one('product.product',string="Most Product Sold",compute="_compute_most_product_sold")
    total_sold_quantity = fields.Float(string="Total Sold Quantity",compute="_compute_total_sold_quantity")
    minimum_sale_price = fields.Float(string="Minimum Sold Price",compute="_compute_min_sale_price")
    maximum_sale_price = fields.Float(string="Maximum Sold Price",compute="_compute_max_sale_price")

    def _compute_most_product_sold(self):
        saleorders=self.sale_order_ids
        products={}
        quantity={}
        for order in saleorders.order_line:
            products[order.id]=order.product_id.name
            quantity[order.id]=order.product_uom_qty
            max=0



        print('products',products)
        print('quantity',quantity)
        # self.write({'most_product_sold':products})
        print(saleorders)

    def _compute_total_sold_quantity(self):
        quantity=0
        saleorders = self.sale_order_ids
        for order in saleorders.order_line:
            quantity+=order.product_uom_qty
        self.write({'total_sold_quantity':quantity})

    def _compute_min_sale_price(self):
        min=0
        total_amount=list()
        saleorders = self.sale_order_ids
        for order in saleorders:
            total_amount.append(order.amount_total)

        mini=set(total_amount)
        print('total amounts', min,total_amount)
        final=list(mini)
        final_min=final[0]

        print('12',final_min)
        self.write({'minimum_sale_price':final_min})

    def _compute_max_sale_price(self):
        print('12')
        maximum = 0
        total_amount = list()
        saleorders = self.sale_order_ids
        for order in saleorders:
            total_amount.append(order.amount_total)
        maximum = max(total_amount)

        # print('123', final_min)
        self.write({'maximum_sale_price':maximum})